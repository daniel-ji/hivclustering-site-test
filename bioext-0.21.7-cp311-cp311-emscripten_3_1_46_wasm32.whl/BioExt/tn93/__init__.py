from BioExt.tn93._tn93 import tn93

__all__ = ['Tn93']
